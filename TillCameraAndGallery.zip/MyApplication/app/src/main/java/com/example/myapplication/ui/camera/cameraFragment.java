package com.example.myapplication.ui.camera;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileObserver;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import com.example.myapplication.R;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.BitSet;
import java.util.Calendar;

import static java.nio.file.Paths.get;
//
//public class cameraFragment extends Fragment {
//
//    private cameraViewModel cameraViewModel;
//    Button takePic;
//    ImageView pic;
//    Button cameraRoll;
//    static final int cameraRequest = 1,selectFile = 0;
//
//    public View onCreateView(@NonNull LayoutInflater inflater,
//                             ViewGroup container, Bundle savedInstanceState) {
//        cameraViewModel =
//                ViewModelProviders.of(this).get(cameraViewModel.class);
//        final View root = inflater.inflate(R.layout.fragment_camera, container, false);
//        final TextView textView = root.findViewById(R.id.text_Camera);
//        cameraViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//                takePic = (Button) root.findViewById(R.id.button_takePic);
//                cameraRoll = (Button) root.findViewById(R.id.button_cameraRoll);
////                if (ContextCompat.checkSelfPermission(getContext(),
////                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
////                    ActivityCompat.requestPermissions(getActivity(),
////                            new String[]{
////                                    Manifest.permission.CAMERA
////                            }, 100);
////                }
//                takePic.setOnClickListener(new View.OnClickListener()
//                {
//                    @Override
//                    public void onClick(View view)
//                    {
//
//                        Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//
//                        startActivityForResult(camera_intent,cameraRequest);
//                        File file = getFile();
//                        camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
//
//                    }
//                });
//
//            }
//        });
//        return root;
//
//    }
//
//    private File getFile(){
//
//        File folder = new File("/sdcard/Pictures");
//        if (folder.exists()) {
//            File image = new File(folder, "new_image.jpg");
//            return image;
//        }
//        return null;
//    }
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        String location = "sdcard/Pictures/new_image.jpg";
//        pic.setImageDrawable(Drawable.createFromPath(location));
//        saveImage(data!!.extras!!.get("data") as Bitmap)
//    }
//
//    fun saveImage(myBitmap: Bitmap):String {
//        BitSet bytes = ByteArrayInputStream();
//        myBitmap.compress(Bitmap.CompressFormat.PNG, 90, bytes)
//        val wallpaperDirectory = File (
//                (Environment.getExternalStorageDirectory()).toString() + IMAGE_DIRECTORY)
//        Log.d("fee", wallpaperDirectory.toString())
//        if (!wallpaperDirectory.exists())
//        {
//            wallpaperDirectory.mkdirs()
//        }
//        try
//        {
//            Log.d("heel", wallpaperDirectory.toString())
//            val f = File(wallpaperDirectory, ((Calendar.getInstance()
//                    .getTimeInMillis()).toString() + ".png"))
//            f.createNewFile()
//            val fo = FileOutputStream(f)
//            fo.write(bytes.toByteArray())
//            MediaScannerConnection.scanFile(this, arrayOf(f.getPath()), arrayOf("image/png"), null)
//            fo.close()
//            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath())
//
//            return f.getAbsolutePath()
//        }
//        catch (e1:IOException){
//            e1.printStackTrace()
//        }
//        return ""
//    }
//
//}




public final class cameraFragment extends Fragment {
    private cameraViewModel cameraViewModel;
    private Button takePic;
    private ImageView pic;
    private Button cameraRoll;
    private final int cameraRequest = 1;
    private int selectFile;
    private final int GALLERY = 1;
    private final int CAMERA = 2;
    private static final String IMAGE_DIRECTORY = "/image";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        cameraViewModel = ViewModelProviders.of(this).get(cameraViewModel.class);
        View root = inflater.inflate(R.layout.fragment_camera, container, false);
        takePic = (Button) root.findViewById(R.id.button_takePic);
        cameraRoll = (Button) root.findViewById(R.id.button_cameraRoll);
        pic = (ImageView) root.findViewById(R.id.picture);
        takePic.setOnClickListener((OnClickListener)(new OnClickListener() {
            public final void onClick(View it) {
                showPictureDialog();
            }
        }));
        return root;
    }

    private final void showPictureDialog() {
        Builder pictureDialog = new Builder((getContext()));
        pictureDialog.setTitle((CharSequence)"Select Action");
        String[] pictureDialogItems = new String[]{"Select image from gallery", "Capture photo from camera"};
        pictureDialog.setItems((CharSequence[])pictureDialogItems, (android.content.DialogInterface.OnClickListener)(new android.content.DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialog, int which) {
                switch(which) {
                    case 0:
                        chooseImageFromGallery();
                        break;
                    case 1:
                        takePhotoFromCamera();
                }

            }
        }));
        pictureDialog.show();
    }

    public final void chooseImageFromGallery() {
        Intent galleryIntent = new Intent("android.intent.action.PICK", Media.EXTERNAL_CONTENT_URI);
        this.startActivityForResult(galleryIntent, this.GALLERY);
    }

    private final void takePhotoFromCamera() {
        Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
        this.startActivityForResult(cameraIntent, this.CAMERA);
    }

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ImageView var10000;
        if (requestCode == this.GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();

                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), contentURI);
                    this.saveImage(bitmap);
                    Toast.makeText((getContext()), (CharSequence)"Image Show!", (int) 0).show();
                    pic.setImageBitmap(bitmap);
                } catch (IOException var6) {
                    var6.printStackTrace();
                    Toast.makeText((getContext()), (CharSequence)"Failed", (int) 0).show();
                }
            }
        } else if (requestCode == this.CAMERA) {

            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            pic.setImageBitmap(thumbnail);
            this.saveImage(thumbnail);
            Toast.makeText((getContext()), (CharSequence)"Photo Show!",  (int) 0).show();

        }

    }


    public final String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(CompressFormat.PNG, 90, (OutputStream)bytes);
        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory().toString() + "/images");
        Log.d("fee", wallpaperDirectory.toString());
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            Log.d("heel", wallpaperDirectory.toString());
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".png");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile((getContext()), new String[]{f.getPath()}, new String[]{"image/png"}, (OnScanCompletedListener)null);
            fo.close();
            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath());

            return f.getAbsolutePath();

        } catch (IOException error) {
            error.printStackTrace();
            return "";
        }
    }


}


